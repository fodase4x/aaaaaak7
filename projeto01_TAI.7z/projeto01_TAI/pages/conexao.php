<?php
//variavel q vao receber oos dados
$mensagem = "preencha o formulario";
$nome ="";
$email ="";
$msg ="";

//verificar se os dados chegam no BD
//os nome devem estar iguais no banco de dados

if (isset($_POST["nome"],$_POST["email"], $_POST['msg'])){
    //iniciando conexão
    $conexao = new PDO("mysql:host=localhost;dbname=site1", "root", "");

    //atribui os valores inputs para variaveis
    //o filter limpa os dados depois de inseridos
    $nome = filter_input(INPUT_POST, "nome", FILTER_UNSAFE_RAW);
    $email = filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL);
    $msg = filter_input(INPUT_POST, "msg", FILTER_UNSAFE_RAW);

    //VERIFICAR SE O USUARIO DIGITOU DADOS INVALIDOS
    if(!$nome || !$email || !$msg){
        $mensagem = "dados invalidos";
    }
    else{
        //vai inserir os dados da tabela db
        $stm = $conexao->prepare('INSERT INTO contato (nome, email, msg) VALUES (:nome, :email, :msg)');

        //bindParam = informar valores dinamicamente para uma requesição
        //sql udsando php, atravez de uma variavel ou constante
        $stm->bindParam('nome', $nome);
        $stm->bindParam('email', $email);
        $stm->bindParam('msg', $msg);
        $stm->execute();

        $mensagem = "Mensagen Enviada com Sucesso";

        //limpar os campos quando a msg for enviada
        
        $nome ="";
        $email ="";
        $msg ="";
    }
}