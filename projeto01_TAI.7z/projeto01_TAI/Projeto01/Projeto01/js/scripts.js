$(function(){
    $('nav.mobile').click(function(){           //quando cluicar ele vai chamar a função
        var listaMenu = $('nav.mobile ul');     //variavel pra ser acessada varias vezes
                                                //listaMenu.slideToggle(); //efeito

        if(listaMenu.slideToggle(':hidden')==true){
        var icone = $('botao-menu-mobile').find('i');
            icone.removeClass('fa-bars');
            icone.addClass('fa-times');
            listaMenu.slideToggle();
        }else{
        var icone = $('botao-menu-mobile').find('i');
            icone.removeClass('fa-times');
            icone.addClass('fa-bars');
            listaMenu.slideToggle();
        }
    
    })
})