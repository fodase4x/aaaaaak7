<?php
include ("conexao.php");
?>
  <div>
    <div class = "center">
      <form method="POST">
      <input required type="text" name="username" value="<?=$nome ?>" placeholder="nome...">
      <div></div>
      <input required type="text" name="email"  value="<?=$email ?>" placeholder="email...">
      <div></div>
      <textarea required placeholder="mensagem..." name="msg"><?=$msg ?></textarea>
      <div></div>
      <input required type="submit" name ="acao" value="Enviar" />
    </form>
    <div class="mensagem"> 
      <?=$mensagem?>
    </div>
  </div>
</div>
  